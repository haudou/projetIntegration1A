/* <DESC>
 * Very simple HTTP POST
 * </DESC>
 */

//Include curl
#include <stdio.h>
#include <string.h>
#include <curl/curl.h>

//Include JSON
#include <cjson/cJSON.h>
#include <cjson/cJSON_Utils.h>

//Include serial port

#include <sys/ioctl.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>


/////////////////////////////////
//Variable

const char *port = "/dev/ttyACM0";
char buffer[255];
int STOP = 0;
/////////////////////////////////
//Main
int main(void) {
    CURL *curl;
    CURLcode res;

    static const char *postthis = "moo mooo moo moo";

    curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, "http://127.0.0.1:5000/Timer");
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postthis);

        /* if we don't provide POSTFIELDSIZE, libcurl will strlen() by
           itself */
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, (long) strlen(postthis));

        /* Perform the request, res will get the return code */
        res = curl_easy_perform(curl);
        /* Check for errors */
        if (res != CURLE_OK)
            fprintf(stderr, "curl_easy_perform() failed: %s\n",
                    curl_easy_strerror(res));

        /* always cleanup */
        curl_easy_cleanup(curl);
    }

    //////////////////////////////////////////////
    //Lire port serie, lecture canonique (Attend un NL ou CR)
    int USB = open(port, O_RDWR | O_NOCTTY);//O_NDELAY
    if(USB < 0)
        perror(USB);
    //read(USB,buffer,255);
    //printf("%s",s);
    struct termios oldtoptions, toptions;

    //Option
    tcgetattr(USB, &oldtoptions);       //Save actual option
    bzero(&toptions, sizeof(toptions)); // clear strut for new port setting
    /*
     * B9600    --> Baudrate
     * CRTSCTS  --> Output hardware control flow ( only use if cable has all necessary lines)
     * CS8      --> 8N1 (8BIT, NO PARITY, 1 STOP BIT)
     * CLOCAL   --> Local connection, no modem control
     * CREAD    --> Enable receiving characters
     */

    toptions.c_cflag = B9600 | CRTSCTS | CS8 | CLOCAL | CREAD;

    /*
     * IGNPAR   --> Ignore bytes parity error
     * ICRNL    --> Map CR to NL (otherwise a CR input on the other computer will not terminate)
     */
    toptions.c_iflag = IGNPAR | ICRNL;

    /*
     * ICANON   --> Enable canoncical input
     */
    toptions.c_oflag = ICANON;

    /*
     * Initialize allcontrol character
     * Default values can be found in /usr/include/termios.h
     */
    toptions.c_cc[VINTR]     = 0; //ctrl-c
    toptions.c_cc[VQUIT]     = 0; //ctrl-v
    toptions.c_cc[VERASE]    = 0; //del
    toptions.c_cc[VKILL]     = 0; //@
    toptions.c_cc[VEOF]      = 4; //ctrl-d
    toptions.c_cc[VTIME]     = 0; // inter-character timer
    toptions.c_cc[VMIN]      = 1; //block until read 1 character
    toptions.c_cc[VSWTC]     = 0; //'\0'
    toptions.c_cc[VSTART]    = 0; //ctrl-q
    toptions.c_cc[VSTOP]     = 0; //ctrl-s
    toptions.c_cc[VSUSP]     = 0; //ctrl-z
    toptions.c_cc[VEOL]      = 0; //\'0'
    toptions.c_cc[VREPRINT]  = 0; //ctrl-r
    toptions.c_cc[VDISCARD]  = 0; //ctrl-u
    toptions.c_cc[VWERASE]   = 0; //ctrl-w
    toptions.c_cc[VLNEXT]    = 0; //ctrl-v
    toptions.c_cc[VEOL2]     = 0; //'\0'

    //Clean the serial
    tcflush(USB, TCIFLUSH);
    tcsetattr(USB, TCSANOW, &toptions);

    while(STOP == 0){
        ssize_t n = read(USB, buffer, 255);
        buffer[n] = '\0'; //Set end of string (for printf)
        printf("%s",buffer);
    }
    tcsetattr(USB, TCSANOW, &oldtoptions);
    close(USB);


    ///////////////////////void doit(char *text)
/////////////
    //cJson

    /*char field_name[32], USBData[32], * out;
    cJSON *root, *names, *ages;

    root =cJSON_CreateObject();
    names = cJSON_CreateArray();
    ages = cJSON_CreateArray();*/
    return 0;
}